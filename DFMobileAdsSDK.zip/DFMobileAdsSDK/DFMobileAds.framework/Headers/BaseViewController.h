//
//  BaseViewController.h
//  DFMobileAds
//
//  Created by frank on 2018/5/30.
//  Copyright © 2018年 DF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
